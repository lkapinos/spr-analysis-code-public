#!/bin/bash

#need path/filename.pdf

#output1: path/eventlog.txt
#output2: path/events.txt

echo
echo
echo "Extract log from pdf"
echo
echo

#extract filename with extension
FILENAME=${1##*/}

#working path
WPATH=${1%/*.*}

#new filename for output of eventlog
NEWFILENAME=${FILENAME%.*}"_eventlog.txt"

#echo $NEWFILENAME

EVENT=${FILENAME%.*}"_events.txt"
SAMPLENAMES=${FILENAME%.*}"_samples.txt"

echo "Output Files:"
echo
echo $EVENT
echo $SAMPLENAMES
echo
echo

pdftotext -layout "$1" "$WPATH/$NEWFILENAME"

grep -P "^(\d|\.)+\s{2,}.+$" "$WPATH/$NEWFILENAME" | perl -pe 's/\ {2,}/\t/g' > "$WPATH/$EVENT"
grep -P "(Sample_\d*_Sample)" "$WPATH/$NEWFILENAME" | perl -pe 's/\ {2,}/\t/g' > "$WPATH/$SAMPLENAMES"


