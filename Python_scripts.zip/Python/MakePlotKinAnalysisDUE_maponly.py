import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.ticker import NullFormatter
import numpy as np
from scipy.optimize import curve_fit
from matplotlib.backends.backend_pdf import PdfPages

font = {'family' : 'Sans-Serif',
        'weight' : 'normal',
        'size'   : 17}

mpl.rc('font', **font)

#Load Data exported from Matlab
mat21 = np.genfromtxt('matrix21.txt',delimiter="\t")[:,:71] #kon map from exp1
mat22 = np.genfromtxt('matrix22.txt',delimiter="\t")[:,:71] #kon map from exp2


mat31 = np.genfromtxt('matrix31.txt',delimiter="\t")[:,:71] #koff map from exp1
mat32 = np.genfromtxt('matrix32.txt',delimiter="\t")[:,:71] #koff map from exp2


#define kon- and koff-range
k11 = np.logspace(0,7,36)
km11 = np.logspace(-6,1,36)

s1 = k11.shape
s1m = km11.shape


#calculate KD from kon/koff pairs
KD = np.zeros((1,s1[0]+s1m[0]-1))

count=0
for i in range(s1[0]-1,-1,-1):
	
	KD[0,count] = km11[0]/k11[i]
	count += 1

for i in range(s1[0]-2,-1,-1):

	KD[0,s1[0]+i] = km11[i+1]/k11[0]


#calculate sum for kon, koff and KD for every exp
kon_sum1 = np.sum(mat21,1)
kon_sum2 = np.sum(mat22,1)

koff_sum1 = np.sum(mat31,1)
koff_sum2 = np.sum(mat32,1)
		
KD_on_sum1 = np.sum(mat21,0)
KD_on_sum2 = np.sum(mat22,0)


#calculate log-axis for x-Axis (KD), y-Axis1 (kon) and y-Axis2 (koff)
logKD=np.log10(KD)[0,:]
logkon_1=np.log10(k11)
logkoff_1=np.log10(km11)





# Define the locations for the axes
zoomfaktor = 1.4

left = 0.1 # and height
height = 0.1
box = 0.25*zoomfaktor #side length of 2d plot
hist_height = 0.08*zoomfaktor
spacesm = 0.01*zoomfaktor
spacebg = 0.015*zoomfaktor


# Set up the geometry of the three plots
rect_koff = [left, height+box+spacebg, box, box] # dimensions of koff 2d plot
rect_kon = [left,height,box,box]# dimensions of kon 2d plot
rect_KD = [left, height+box+spacebg+box+spacesm, box, hist_height] # dimensions of KD-histogram
rect_Histkoff = [left+box+spacesm, height+box+spacebg, hist_height, box] # dimensions of koff-histogram
rect_Histkon = [left+box+spacesm, height, hist_height, box] # dimensions of kon-histogram

# Set up the size of the figure
fig = plt.figure(1, figsize=(9,9))

# Make the three plots
axkon = plt.axes(rect_kon) # kon 2d plot
axkoff = plt.axes(rect_koff)
axKD = plt.axes(rect_KD) # x histogram
axHistkon = plt.axes(rect_Histkon) # y histogram
axHistkoff = plt.axes(rect_Histkoff)

# Remove the axes numbers of the histograms and 2d plots
nullfmt = NullFormatter()
nullloc = plt.NullLocator()
axkoff.xaxis.set_major_formatter(nullfmt)
axKD.xaxis.set_major_formatter(nullfmt)
axKD.yaxis.set_major_formatter(nullfmt)
axKD.yaxis.set_major_locator(nullloc)
axHistkon.yaxis.set_major_formatter(nullfmt)
axHistkon.xaxis.set_major_formatter(nullfmt)
axHistkon.xaxis.set_major_locator(nullloc)
axHistkoff.yaxis.set_major_formatter(nullfmt)
axHistkoff.xaxis.set_major_formatter(nullfmt)
axHistkoff.xaxis.set_major_locator(nullloc)

#Normalize Sums and Fits
KD_on_sum1 /= np.sum(KD_on_sum1,0)
KD_on_sum2 /= np.sum(KD_on_sum2,0)

kon_sum1 /= np.sum(kon_sum1,0)
kon_sum2 /= np.sum(kon_sum2,0)

koff_sum1 /= np.sum(koff_sum1,0)
koff_sum2 /= np.sum(koff_sum2,0)


#plot data
lvls = np.linspace(0.1,10,num=10,endpoint=True)

Cblue = np.genfromtxt('colormapblue.txt')
Cred = np.genfromtxt('colormapred.txt')

cmBlue = mpl.colors.ListedColormap(Cblue/255)
cmRed = mpl.colors.ListedColormap(Cred/255)


contkon1=axkon.contourf(logKD,logkon_1,mat21,alpha=0.5,levels=lvls,cmap=cmBlue ) #plot kon 2d maps
contkon1=axkon.contour(logKD,logkon_1,mat21,alpha=0.5,levels=lvls,cmap=cmBlue )
contkon2=axkon.contourf(logKD,logkon_1,mat22,alpha=0.5,levels=lvls,cmap=cmRed)
contkon2=axkon.contour(logKD,logkon_1,mat22,alpha=0.5,levels=lvls,cmap=cmRed)


contkoff1=axkoff.contourf(logKD,logkoff_1,mat31,alpha=0.5,levels=lvls,cmap=cmBlue )
contkoff1=axkoff.contour(logKD,logkoff_1,mat31,alpha=1,levels=lvls,cmap=cmBlue )
contkoff2=axkoff.contourf(logKD,logkoff_1,mat32,alpha=0.5,levels=lvls,cmap=cmRed)
contkoff2=axkoff.contour(logKD,logkoff_1,mat32,alpha=1,levels=lvls,cmap=cmRed)

axkon.xaxis.grid(True, zorder=0)
axkon.yaxis.grid(True, zorder=0)
axkoff.xaxis.grid(True, zorder=0)
axkoff.yaxis.grid(True, zorder=0)
axkon.set_xlim([-10,-5])
axkoff.set_xlim([-10,-5])

axkon.set_xlabel("log(KD)", fontsize=15)
axkon.set_ylabel("log(kon)", fontsize=15)
axkoff.set_ylabel("log(koff)", fontsize=15)


axKD.bar(logKD,KD_on_sum1,0.2,align='center',alpha=0.5,color=cmBlue(1))
axKD.bar(logKD,KD_on_sum2,0.2,align='center',alpha=0.5,color=cmRed(1))
axKD.set_xlim([-10,-5])
axKD.set_ylim([0,0.25])
axKD.xaxis.grid(True, zorder=0)

axHistkoff.barh(logkoff_1,koff_sum1,0.2,align='center',alpha=0.5,color=cmBlue(1))
axHistkoff.barh(logkoff_1,koff_sum2,0.2,align='center',alpha=0.5,color=cmRed(1))
axHistkoff.set_ylim([-6,1])
axHistkoff.set_xlim([0,0.22])
axHistkoff.yaxis.grid(True, zorder=0)


axHistkon.barh(logkon_1,kon_sum1,0.2,align='center',alpha=0.5,color=cmBlue(1))
axHistkon.barh(logkon_1,kon_sum2,0.2,align='center',alpha=0.5,color=cmRed(1))
axHistkon.set_ylim([0,7])
axHistkon.set_xlim([0,0.22])
axHistkon.yaxis.grid(True, zorder=0)

plt.show()

pp = PdfPages('Test.pdf')
pp.savefig(fig)
pp.close()
