import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib.ticker import NullFormatter
import numpy as np
from scipy.optimize import curve_fit
from matplotlib.backends.backend_pdf import PdfPages

font = {'family' : 'Sans-Serif',
        'weight' : 'normal',
        'size'   : 17}

mpl.rc('font', **font)

#Load Data exported from Matlab
mat21 = np.genfromtxt('matrix21.txt',delimiter="\t")[:,:71] #kon map from exp1
mat22 = np.genfromtxt('matrix22.txt',delimiter="\t")[:,:71] #kon map from exp2
mat23 = np.genfromtxt('matrix23.txt',delimiter="\t")[:,:71] #kon map from exp3


mat31 = np.genfromtxt('matrix31.txt',delimiter="\t")[:,:71] #koff map from exp1
mat32 = np.genfromtxt('matrix32.txt',delimiter="\t")[:,:71] #koff map from exp2
mat33 = np.genfromtxt('matrix33.txt',delimiter="\t")[:,:71] #koff map from exp3


#define kon- and koff-range
k11 = np.logspace(0,7,36)
km11 = np.logspace(-6,1,36)

s1 = k11.shape
s1m = km11.shape


#calculate KD from kon/koff pairs
KD = np.zeros((1,s1[0]+s1m[0]-1))

count=0
for i in range(s1[0]-1,-1,-1):
	
	KD[0,count] = km11[0]/k11[i]
	count += 1

for i in range(s1[0]-2,-1,-1):

	KD[0,s1[0]+i] = km11[i+1]/k11[0]


#calculate sum for kon, koff and KD for every exp
kon_sum1 = np.sum(mat21,1)
kon_sum2 = np.sum(mat22,1)
kon_sum3 = np.sum(mat23,1)

koff_sum1 = np.sum(mat31,1)
koff_sum2 = np.sum(mat32,1)
koff_sum3 = np.sum(mat33,1)
		
KD_on_sum1 = np.sum(mat21,0)
KD_on_sum2 = np.sum(mat22,0)
KD_on_sum3 = np.sum(mat23,0)


#calculate log-axis for x-Axis (KD), y-Axis1 (kon) and y-Axis2 (koff)
logKD=np.log10(KD)[0,:]
logkon_1=np.log10(k11)
logkoff_1=np.log10(km11)


#define gauss-fit functions
def gauss1(x, *p):
	return p[0]*np.exp(-((x-p[1])**2)/(2*p[2]**2)) #gauss with 1 peak

def gauss2(x, *p):
	return p[0]*np.exp(-((x-p[1])**2)/(2*p[2]**2))+p[3]*np.exp(-((x-p[4])**2)/(2*p[5]**2)) #gauss with 2 peaks

def gauss3(x, *p):
	return p[0]*np.exp(-((x-p[1])**2)/(2*p[2]**2))+p[3]*np.exp(-((x-p[4])**2)/(2*p[5]**2))+p[6]*np.exp(-((x-p[7])**2)/(2*p[8]**2)) #gauss with 3 peaks

def gauss4(x, *p):
	return p[0]*np.exp(-((x-p[1])**2)/(2*p[2]**2))+p[3]*np.exp(-((x-p[4])**2)/(2*p[5]**2))+p[6]*np.exp(-((x-p[7])**2)/(2*p[8]**2))+p[9]*np.exp(-((x-p[10])**2)/(2*p[11]**2)) #gauss with 4 peaks


#initial guesses for gauss fits
#KDs
p0_KD_on_1 = [5,-5,0.2] #initial guesses for fitting sum of KDs for exp1 
p0_KD_on_2 = [15,-5.8,0.2] #initial guesses for fitting sum of KDs for exp2
p0_KD_on_3 = [10,-6.8,0.2] #initial guesses for fitting sum of KDs for exp3
#kon
p0_kon_sum_1 = [5,5,0.2] #initial guesses for fitting sum o kons for exp1
p0_kon_sum_2 = [10,1,0.2] #initial guesses for fitting sum of kons for exp2
p0_kon_sum_3 = [10,0.8,0.2] #initial guesses for fitting sum of kons for exp3
#koff
p0_koff_sum_1 = [5,0.2,0.2] #initial guesses for fitting sum o koffs for exp1
p0_koff_sum_2 = [15,-4.8,0.2] #initial guesses for fitting sum of koffs for exp2
p0_koff_sum_3 = [15,-5.8,0.2] #initial guesses for fitting sum of koffs for exp3

#fitting with error-handling
#KDs
try:
	p1_KD_on_1,success = curve_fit(gauss1, logKD, KD_on_sum1, p0_KD_on_1)
except RuntimeError:
	print ("Error - curve_fit KD_on_sum1 failed")
Fit_KD1 = gauss1(logKD,*p1_KD_on_1)

try:
	p1_KD_on_2,success = curve_fit(gauss1, logKD, KD_on_sum2, p0_KD_on_2)
except RuntimeError:
	print ("Error - curve_fit KD_on_sum2 failed")
Fit_KD2 = gauss1(logKD,*p1_KD_on_2)

try:
	p1_KD_on_3,success = curve_fit(gauss1, logKD, KD_on_sum3, p0_KD_on_3)
except RuntimeError:
	print ("Error - curve_fit KD_on_sum3 failed")
Fit_KD2 = gauss1(logKD,*p1_KD_on_3)

#kons
try:
	p1_kon_sum_1,success = curve_fit(gauss1, logkon_1, kon_sum1, p0_kon_sum_1)
except RuntimeError:
	print ("Error - curve_fit kon_sum1 failed")
Fit_kon1 = gauss1(logkon_1,*p1_kon_sum_1)

try:
	p1_kon_sum_2,success = curve_fit(gauss1, logkon_1, kon_sum2, p0_kon_sum_2)
except RuntimeError:
	print ("Error - curve_fit kon_sum2 failed")
Fit_kon2 = gauss1(logkon_1,*p1_kon_sum_2)


try:
	p1_kon_sum_3,success = curve_fit(gauss1, logkon_1, kon_sum3, p0_kon_sum_3)
except RuntimeError:
	print ("Error - curve_fit kon_sum2 failed")
Fit_kon2 = gauss1(logkon_1,*p1_kon_sum_3)


#koffs
try:
	p1_koff_sum_1,success = curve_fit(gauss1, logkoff_1, koff_sum1, p0_koff_sum_1)
except RuntimeError:
	print ("Error - curve_fit koff_sum1 failed")
Fit_koff1 = gauss1(logkoff_1,*p1_koff_sum_1)

try:
	p1_koff_sum_2,success = curve_fit(gauss1, logkoff_1, koff_sum2, p0_koff_sum_2)
except RuntimeError:
	print ("Error - curve_fit koff_sum2 failed")
Fit_koff2 = gauss1(logkoff_1,*p1_koff_sum_2)


try:
	p1_koff_sum_3,success = curve_fit(gauss1, logkoff_1, koff_sum3, p0_koff_sum_3)
except RuntimeError:
	print ("Error - curve_fit koff_sum3 failed")
Fit_koff3 = gauss1(logkoff_1,*p1_koff_sum_3)


#calculate fraction of individual gauss peaks (integrated and normalized by the total)
#KD1
fracs_KD_on_1 = np.empty(len(p0_KD_on_1)/3)
for i in range(0,len(p0_KD_on_1),3):
	fracs_KD_on_1[i/3] = p1_KD_on_1[i]*abs( p1_KD_on_1[i+2])*np.sqrt(np.pi)

Normfracs_KD_on_1 = fracs_KD_on_1/np.sum(fracs_KD_on_1) #normalized wheight of each kinetic species (gauss peak)
#KD2
fracs_KD_on_2 = np.empty(len(p0_KD_on_2)/3)
for i in range(0,len(p0_KD_on_2),3):
	fracs_KD_on_2[i/3] = p1_KD_on_2[i]*abs( p1_KD_on_2[i+2])*np.sqrt(np.pi)
#KD3
fracs_KD_on_3 = np.empty(len(p0_KD_on_3)/3)
for i in range(0,len(p0_KD_on_2),3):
	fracs_KD_on_3[i/3] = p1_KD_on_3[i]*abs( p1_KD_on_3[i+2])*np.sqrt(np.pi)


#kon1
fracs_kon_sum_1 = np.empty(len(p0_kon_sum_1)/3)
for i in range(0,len(p0_kon_sum_1),3):
	fracs_kon_sum_1[i/3] = p1_kon_sum_1[i]*abs( p1_kon_sum_1[i+2])*np.sqrt(np.pi)

Normfracs_kon_sum_1 = fracs_kon_sum_1/np.sum(fracs_kon_sum_1) #normalized wheight of each kinetic species (gauss peak)

#kon2
fracs_kon_sum_2 = np.empty(len(p0_kon_sum_2)/3)
for i in range(0,len(p0_kon_sum_2),3):
	fracs_kon_sum_2[i/3] = p1_kon_sum_2[i]*abs( p1_kon_sum_2[i+2])*np.sqrt(np.pi)

#kon3
fracs_kon_sum_3 = np.empty(len(p0_kon_sum_3)/3)
for i in range(0,len(p0_kon_sum_3),3):
	fracs_kon_sum_3[i/3] = p1_kon_sum_3[i]*abs( p1_kon_sum_3[i+2])*np.sqrt(np.pi)

#koff1
fracs_koff_sum_1 = np.empty(len(p0_koff_sum_1)/3)
for i in range(0,len(p0_koff_sum_1),3):
	fracs_koff_sum_1[i/3] = p1_koff_sum_1[i]*abs( p1_koff_sum_1[i+2])*np.sqrt(np.pi)

Normfracs_koff_sum_1 = fracs_koff_sum_1/np.sum(fracs_koff_sum_1) #normalized wheight of each kinetic species (gauss peak)

#koff2
fracs_koff_sum_2 = np.empty(len(p0_koff_sum_2)/3)
for i in range(0,len(p0_koff_sum_2),3):
	fracs_koff_sum_2[i/3] = p1_koff_sum_2[i]*abs( p1_koff_sum_2[i+2])*np.sqrt(np.pi)

#koff3
fracs_koff_sum_3 = np.empty(len(p0_koff_sum_3)/3)
for i in range(0,len(p0_koff_sum_3),3):
	fracs_koff_sum_3[i/3] = p1_koff_sum_3[i]*abs( p1_koff_sum_3[i+2])*np.sqrt(np.pi)


#print fit results
print ("\nTHIS HELLO-WORLD PROGRAM EVALUATES THE MULTIVALENT KINETIC ANALYSIS RESULTS and creates a nice figure\n")
print ("\n================= DISTRIBUTION FIT RESULTS ====================\n")
print ("\nKD1 = "), p1_KD_on_1, ("\n")
print ("KD2 = "), p1_KD_on_2, ("\n")
print ("kon1 = "), p1_kon_sum_1, ("\n")
print ("kon2 = "), p1_kon_sum_2, ("\n")
print ("koff1 = "), p1_koff_sum_1, ("\n")
print ("koff2 = "), p1_koff_sum_2, ("\n")


#print total sum of histogramms
print ("\n================= SUMs ====================\n")
print ("\nexp1 total sum = "), np.sum(KD_on_sum1), ("\n")
print ("\nexp2 total sum = "), np.sum(KD_on_sum2), ("\n")

#print main result of kintic species distribution
print ("\n================= RESULT KINETIC DISTRIBUTION ====================\n")
print ("\n(log10(val); val (KD, kon or koff); Fraction; Sigma)\n")
print ("\nKD1 distribution (uM):\n")
for i in range(0,len(p0_KD_on_1),3):
	print p1_KD_on_1[i+1],(";"),10**p1_KD_on_1[i+1]*(10**6),(";"),Normfracs_KD_on_1[i/3],(";"),p1_KD_on_1[i+2],("\n")
print ("\nKD2 distribution (uM):\n")
for i in range(0,len(p0_KD_on_2),3):
	print p1_KD_on_2[i+1],(";"),10**p1_KD_on_2[i+1]*(10**6),(";"),Normfracs_KD_on_2[i/3],(";"),p1_KD_on_2[i+2],("\n")
print ("\nkon1 distribution (M-1s-1):\n")
for i in range(0,len(p0_kon_sum_1),3):
	print p1_kon_sum_1[i+1],(";"),10**p1_kon_sum_1[i+1],(";"),Normfracs_kon_sum_1[i/3],(";"),p1_kon_sum_1[i+2],("\n")
print ("\nkon2 distribution (M-1s-1):\n")
for i in range(0,len(p0_kon_sum_2),3):
	print p1_kon_sum_2[i+1],(";"),10**p1_kon_sum_2[i+1],(";"),Normfracs_kon_sum_2[i/3],(";"),p1_kon_sum_2[i+2],("\n")
print ("\nkoff1 distribution (s-1):\n")
for i in range(0,len(p0_koff_sum_1),3):
	print p1_koff_sum_1[i+1],(";"),10**p1_koff_sum_1[i+1],(";"),Normfracs_koff_sum_1[i/3],(";"),p1_koff_sum_1[i+2],("\n")
print ("\nkoff2 distribution (s-1):\n")
for i in range(0,len(p0_koff_sum_2),3):
	print p1_koff_sum_2[i+1],(";"),10**p1_koff_sum_2[i+1],(";"),Normfracs_koff_sum_2[i/3],(";"),p1_koff_sum_2[i+2],("\n")


# Define the locations for the axes
zoomfaktor = 1.4

left = 0.1 # and height
height = 0.1
box = 0.25*zoomfaktor #side length of 2d plot
hist_height = 0.08*zoomfaktor
spacesm = 0.01*zoomfaktor
spacebg = 0.015*zoomfaktor


# Set up the geometry of the three plots
rect_koff = [left, height+box+spacebg, box, box] # dimensions of koff 2d plot
rect_kon = [left,height,box,box]# dimensions of kon 2d plot
rect_KD = [left, height+box+spacebg+box+spacesm, box, hist_height] # dimensions of KD-histogram
rect_Histkoff = [left+box+spacesm, height+box+spacebg, hist_height, box] # dimensions of koff-histogram
rect_Histkon = [left+box+spacesm, height, hist_height, box] # dimensions of kon-histogram

# Set up the size of the figure
fig = plt.figure(1, figsize=(9,9))

# Make the three plots
axkon = plt.axes(rect_kon) # kon 2d plot
axkoff = plt.axes(rect_koff)
axKD = plt.axes(rect_KD) # x histogram
axHistkon = plt.axes(rect_Histkon) # y histogram
axHistkoff = plt.axes(rect_Histkoff)

# Remove the axes numbers of the histograms and 2d plots
nullfmt = NullFormatter()
nullloc = plt.NullLocator()
axkoff.xaxis.set_major_formatter(nullfmt)
axKD.xaxis.set_major_formatter(nullfmt)
axKD.yaxis.set_major_formatter(nullfmt)
axKD.yaxis.set_major_locator(nullloc)
axHistkon.yaxis.set_major_formatter(nullfmt)
axHistkon.xaxis.set_major_formatter(nullfmt)
axHistkon.xaxis.set_major_locator(nullloc)
axHistkoff.yaxis.set_major_formatter(nullfmt)
axHistkoff.xaxis.set_major_formatter(nullfmt)
axHistkoff.xaxis.set_major_locator(nullloc)

#Normalize Sums and Fits
KD_on_sum1 /= np.sum(KD_on_sum1,0)
KD_on_sum2 /= np.sum(KD_on_sum2,0)
KD_on_sum3 /= np.sum(KD_on_sum3,0)


Fit_KD1 /= np.sum(Fit_KD1,0)
Fit_KD2 /= np.sum(Fit_KD2,0)


kon_sum1 /= np.sum(kon_sum1,0)
kon_sum2 /= np.sum(kon_sum2,0)
kon_sum3 /= np.sum(kon_sum3,0)


Fit_kon1 /= np.sum(Fit_kon1,0)
Fit_kon2 /= np.sum(Fit_kon2,0)


koff_sum1 /= np.sum(koff_sum1,0)
koff_sum2 /= np.sum(koff_sum2,0)
koff_sum3 /= np.sum(koff_sum3,0)


Fit_koff1 /= np.sum(Fit_koff1,0)
Fit_koff2 /= np.sum(Fit_koff2,0)




#plot data
lvls = np.linspace(0.3,10,num=50,endpoint=True)

Cblue = np.genfromtxt('colormapblue.txt')
Cred = np.genfromtxt('colormapred.txt')
Cgreen = np.genfromtxt('colormapgreen.txt')

cmBlue = mpl.colors.ListedColormap(Cblue/255)
cmRed = mpl.colors.ListedColormap(Cred/255)
cmGreen = mpl.colors.ListedColormap(Cgreen/255)


contkon1=axkon.contourf(logKD,logkon_1,mat21,alpha=0.5,levels=lvls,cmap=cmBlue ) #plot kon 2d maps
#contkon1=axkon.contour(logKD,logkon_1,mat21,alpha=0.5,levels=lvls,cmap=cmBlue )
contkon2=axkon.contourf(logKD,logkon_1,mat22,alpha=0.5,levels=lvls,cmap=cmRed)
#contkon2=axkon.contour(logKD,logkon_1,mat22,alpha=0.5,levels=lvls,cmap=cmRed)


contkoff1=axkoff.contourf(logKD,logkoff_1,mat31,alpha=0.5,levels=lvls,cmap=cmBlue )
#contkoff1=axkoff.contour(logKD,logkoff_1,mat31,alpha=1,levels=lvls,cmap=cmBlue )
contkoff2=axkoff.contourf(logKD,logkoff_1,mat32,alpha=0.5,levels=lvls,cmap=cmRed)
#contkoff2=axkoff.contour(logKD,logkoff_1,mat32,alpha=1,levels=lvls,cmap=cmRed)

axkon.xaxis.grid(True, zorder=0)
axkon.yaxis.grid(True, zorder=0)
axkoff.xaxis.grid(True, zorder=0)
axkoff.yaxis.grid(True, zorder=0)
axkon.set_xlim([-10,-3])
axkoff.set_xlim([-10,-3])

axkon.set_xlabel("log(KD)", fontsize=15)
axkon.set_ylabel("log(kon)", fontsize=15)
axkoff.set_ylabel("log(koff)", fontsize=15)


axKD.bar(logKD,KD_on_sum1,0.2,align='center',alpha=0.5,color=cmBlue(1))
axKD.bar(logKD,KD_on_sum2,0.2,align='center',alpha=0.5,color=cmRed(1))
axKD.plot(logKD,Fit_KD1,color=cmBlue(1))
axKD.plot(logKD,Fit_KD2,color=cmRed(1))
axKD.set_xlim([-10,-3])
axKD.xaxis.grid(True, zorder=0)

axHistkoff.barh(logkoff_1,koff_sum1,0.2,align='center',alpha=0.5,color=cmBlue(1))
axHistkoff.barh(logkoff_1,koff_sum2,0.2,align='center',alpha=0.5,color=cmRed(1))
axHistkoff.plot(Fit_koff1,logkoff_1,color=cmBlue(1))
axHistkoff.plot(Fit_koff2,logkoff_1,color=cmRed(1))
axHistkoff.set_ylim([-6,1])
#axHistkoff.set_xlim([0,0.5])
axHistkoff.yaxis.grid(True, zorder=0)


axHistkon.barh(logkon_1,kon_sum1,0.2,align='center',alpha=0.5,color=cmBlue(1))
axHistkon.barh(logkon_1,kon_sum2,0.2,align='center',alpha=0.5,color=cmRed(1))
axHistkon.plot(Fit_kon1,logkon_1,color=cmBlue(1))
axHistkon.plot(Fit_kon2,logkon_1,color=cmRed(1))
axHistkon.set_ylim([0,7])
#axHistkon.set_xlim([0,0.5])
axHistkon.yaxis.grid(True, zorder=0)

plt.show()

pp = PdfPages('Test.pdf')
pp.savefig(fig)
pp.close()
